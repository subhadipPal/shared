import { combineReducers } from "redux";
import { reducer as formReducer } from "redux-form";

const initialState = {
  users: [
    {
      name: "John",
      id: 0,
      hobbies: [
        { id: 0, hobby: "Video Games", passion: "Medium", since: "2010" },
        { id: 1, hobby: "Playing Tennis", passion: "Medium", since: "2014" },
        { id: 2, hobby: "Going To Cinema", passion: "High", since: "2016" },
        { id: 3, hobby: "Listening To Music", passion: "Low", since: "2012" }
      ]
    },
    {
      name: "Peter",
      id: 1,
      hobbies: [
        {
          id: 0,
          hobby: "Playing football",
          passion: "Medium",
          since: "2014"
        },
        {
          id: 1,
          hobby: "Listening To Music",
          passion: "High",
          since: "2007"
        },
        { id: 2, hobby: "Going To Concert", passion: "Low", since: "2015" },
        { id: 3, hobby: "Coding", passion: "Very-High    ", since: "2016" }
      ]
    },
    {
      name: "Markus",
      id: 2,
      hobbies: [
        { id: 0, hobby: "Reading Novels", passion: "Medium", since: "2010" },
        {
          id: 1,
          hobby: "Listening To Music",
          passion: "High",
          since: "2007"
        },
        { id: 2, hobby: "Singing", passion: "Low", since: "2009" },
        {
          id: 3,
          hobby: "Scuba diving",
          passion: "Very-High    ",
          since: "2015"
        }
      ]
    }
  ]
};

function usersReducer(state, action) {
  if (typeof state === "undefined") {
    return Object.assign({}, initialState);
  }
  let users,
    user = "";
  switch (action.type) {
    case "USER_SELECTED":
      return {
        users: state.users,
        user: action.payload
      };
    case "ADD_USER":
      users = [...state.users];
      let ids = users.map(user => {
        return user.id;
      });
      const newId = ids[ids.length - 1] + 1;
      const newUser = {
        id: newId,
        name: action.payload.name,
        hobbies: []
      };
      return {
        users: [...users, newUser]
      };
    case "DELETE_HOBBY":
      users = [...state.users];
      user = state.user;
      user.hobbies = user.hobbies.filter(hobby => {
        return hobby.id !== action.payload.id;
      });
      return {
        users,
        user
      };

    case "ADD_HOBBY":
      user = state.user;
      let hobbies = user.hobbies;
      let hobbyIds = hobbies.map(hobby => {
        return hobby.id;
      });
      let newHobby = {
        id: hobbyIds[hobbyIds.length - 1] + 1,
        passion: action.payload.passion,
        hobby: action.payload.hobby,
        since: action.payload.since
      };
      user.hobbies.push(newHobby);
      return {
        users: state.users,
        user
      };
    default:
      return state;
  }
}

export default combineReducers({
  usersReducer,
  form: formReducer
});
