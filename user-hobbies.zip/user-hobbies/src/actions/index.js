export const fetchUserHobbies = () => {
  return {
    type: "FETCH_USER_HOBBIES"
  };
};
export const selectUser = user => {
  return {
    type: "USER_SELECTED",
    payload: user
  };
};

export const deleteHobby = hobby => {
  return {
    type: "DELETE_HOBBY",
    payload: hobby
  };
};

export const addUserAction = user => {
  return {
    type: "ADD_USER",
    payload: user
  };
};

export const addHobby = hobby => {
  return {
    type: "ADD_HOBBY",
    payload: hobby
  };
};
