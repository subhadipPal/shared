import React, { Component } from "react";
import AddUserHobbyForm from "./form/AddUserHobbyForm";

class UserDetails extends Component {
  renderUserDetails({ currentUser, deleteHobby } = this.props) {
    return currentUser.hobbies.map(hobby => {
      return (
        <div className="row" key={hobby.id}>
          <div className="column">{hobby.hobby}</div>
          <div className="column">{hobby.passion}</div>
          <div className="column">{hobby.since}</div>
          <div className="column">
            <i
              className="red trash icon"
              onClick={e => {
                deleteHobby(hobby);
              }}
            />
          </div>
        </div>
      );
    });
  }

  render() {
    return (
      <div>
        {this.props.currentUser ? (
          <div>
            <h4>Hobby Details of {this.props.currentUser.name}</h4>
            <hr />
            <div>
              <AddUserHobbyForm addHobby={this.props.addHobby} />
            </div>
            <div className="ui container">
              <div className="ui four column grid">
                <div className="row" style={{ textDecoration: "underline" }}>
                  <div className="column">Hobby</div>
                  <div className="column">Passion</div>
                  <div className="column">Since</div>
                  <div className="column" />
                </div>
                {this.renderUserDetails()}
              </div>
            </div>
          </div>
        ) : (
          <div>
            <h4>Hobby Details</h4>
            <hr />
          </div>
        )}
      </div>
    );
  }
}

export default UserDetails;
