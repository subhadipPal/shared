import React, { Component } from "react";
import "./UserList.css";
import AddNewUserForm from "./form/AddNewUserForm";

class UserList extends Component {
  componentDidMount() {}

  renderUserList({ users, selectUser } = this.props) {
    return users.map(user => {
      return (
        <div
          className="item user-list-item"
          key={user.id}
          style={{ height: "40px" }}
          onClick={() => {
            selectUser(user);
          }}
        >
          <div className="content">{user.name}</div>
        </div>
      );
    });
  }

  render() {
    return (
      <div>
        <h4>User List</h4>
        <hr />
        <AddNewUserForm addUserAction={this.props.addUserAction} />
        <div className="ui container">
          <div className="ui divided list">{this.renderUserList()}</div>
        </div>
      </div>
    );
  }
}

export default UserList;
