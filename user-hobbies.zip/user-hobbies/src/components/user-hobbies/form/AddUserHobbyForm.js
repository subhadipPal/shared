import React from "react";
import { reduxForm, Field } from "redux-form";

const renderInput = ({ input, type, label }) => {
  return (
    <div>
      <div>
        <input {...input} type={type} placeholder={label} />
      </div>
    </div>
  );
};

const onSubmit = (values, dispatch, addHobby) => {
  addHobby({
    passion: values.passion,
    hobby: values.hobby,
    since: values.since
  });
};

const AddUserHobbyForm = props => {
  return (
    <div className="ui segment" style={{ height: "70px" }}>
      <form
        className="ui form"
        onSubmit={props.handleSubmit((values, dispatch) => {
          onSubmit(values, dispatch, props.addHobby);
        })}
      >
        <div className="ui left action input">
          <div className="ui grid">
            <Field
              name="hobby"
              component={renderInput}
              label="Enter user hobby"
              type="text"
            />
            <Field
              name="passion"
              component={renderInput}
              label="Enter Passion"
              type="text"
            />
            <Field
              name="since"
              component={renderInput}
              label="Enter year"
              type="text"
            />
            <button className="ui blue submit button">Add</button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default reduxForm({
  form: "add-user-hobby",
  onSubmit
})(AddUserHobbyForm);
