import React from "react";
import { reduxForm, Field } from "redux-form";

const renderInput = props => {
  return (
    <div>
      <div>
        <input {...props.input} type="text" />
      </div>
    </div>
  );
};

const onSubmit = (values, dispatch, addUserAction) => {
  addUserAction({
    name: values.user
  });
};

const AddNewUserForm = props => {
  console.log(props);
  return (
    <div className="ui segment">
      <form
        className="ui form"
        onSubmit={props.handleSubmit((values, dispatch) => {
          onSubmit(values, dispatch, props.addUserAction);
        })}
      >
        <div className="ui left action input">
          <div>
            <Field
              name="user"
              component={renderInput}
              label="User Name"
              type="text"
            />
          </div>
          <button className="ui blue submit button">Add</button>
        </div>
      </form>
    </div>
  );
};

export default reduxForm({
  form: "add-new-user",
  onSubmit
})(AddNewUserForm);
