import React, { Component } from "react";
import { connect } from "react-redux";
import {
  selectUser,
  fetchUserHobbies,
  deleteHobby,
  addUserAction,
  addHobby
} from "../actions";

import ResizeablePanel from "./resizablePanel/ResizeablePanel";
import UserList from "./user-hobbies/UserList";
import UserDetails from "./user-hobbies/UserDetails";

class App extends Component {
  render() {
    console.log(this.props);
    return (
      <div>
        <h1>User hobbies</h1>
        <ResizeablePanel>
          <div>
            <UserList
              users={this.props.users.users}
              selectUser={this.props.selectUser}
              addUserAction={this.props.addUserAction}
            />
          </div>
          <div>
            <UserDetails
              currentUser={this.props.users.user}
              deleteHobby={this.props.deleteHobby}
              addHobby={this.props.addHobby}
            />
          </div>
        </ResizeablePanel>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    users: state.usersReducer
  };
};

const mapDispatchToProps = dispatch => ({
  fetchUserHobbies: () => {
    dispatch(fetchUserHobbies());
  },
  selectUser: user => {
    dispatch(selectUser(user));
  },
  deleteHobby: hobby => {
    dispatch(deleteHobby(hobby));
  },
  addUserAction: user => {
    dispatch(addUserAction(user));
  },
  addHobby: hobby => {
    dispatch(addHobby(hobby));
  }
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App);
